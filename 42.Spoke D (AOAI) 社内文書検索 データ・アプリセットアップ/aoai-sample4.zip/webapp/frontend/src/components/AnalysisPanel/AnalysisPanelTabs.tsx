export enum AnalysisPanelTabs {
    ThoughtProcessTab = "thoughtProcess",
    SupportingContentTab = "supportingContent",
    CitationTab = "citation"
}
